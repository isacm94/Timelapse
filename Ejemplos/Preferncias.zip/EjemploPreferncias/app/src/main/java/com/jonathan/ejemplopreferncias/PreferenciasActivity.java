package com.jonathan.ejemplopreferncias;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

/**
 * Created by jarmada on 24/01/2017.
 */

public class PreferenciasActivity extends AppCompatActivity {

    String bat, cal, memo, fre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getFragmentManager().beginTransaction()
                .replace(android.R.id.content, new PreferenciasFragment())
                .commit();
        SharedPreferences shaPref = PreferenceManager.getDefaultSharedPreferences(this);

        bat = shaPref.getString("bateria", "");
        cal = shaPref.getString("calidad", "");
        memo = shaPref.getString("memoria", "");
        fre = shaPref.getString("frecuencia", "");

        Toast.makeText(this, bat+"bateria "+fre+"frecuencia "+ "·memoria: "+ memo+"calidad"+cal, Toast.LENGTH_SHORT).show();
    }


}
