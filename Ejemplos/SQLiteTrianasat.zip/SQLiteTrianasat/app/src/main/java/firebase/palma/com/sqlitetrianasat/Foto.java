package firebase.palma.com.sqlitetrianasat;

/**
 * Created by jmpgallego on 25/01/2017.
 */

public class Foto {

    private Long id;
    private Long fecha;
    private Posicion pos;
    private Double bateria;

    public Foto() {

    }

    public Foto(Long id, Long fecha, Posicion pos, Double bateria) {
        this.id = id;
        this.fecha = fecha;
        this.pos = pos;
        this.bateria = bateria;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFecha() {
        return fecha;
    }

    public void setFecha(Long fecha) {
        this.fecha = fecha;
    }

    public Posicion getPos() {
        return pos;
    }

    public void setPos(Posicion pos) {
        this.pos = pos;
    }

    public Double getBateria() {
        return bateria;
    }

    public void setBateria(Double bateria) {
        this.bateria = bateria;
    }
}
