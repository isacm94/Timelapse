package firebase.palma.com.sqlitetrianasat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    //Lo suyo es coger todas las imágenes y que las pinte en un grid

    ImageView imageViewExterna;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageViewExterna = (ImageView) findViewById(R.id.imageview_externa);

        //Creando la base de datos
        db = this.openOrCreateDatabase("test.db", Context.MODE_PRIVATE, null);
        db.execSQL("create table if not exists tb (a blob)");
    }

    public void guardarImagen(View view) {

        try {
            File extStore = Environment.getExternalStorageDirectory();
            FileInputStream fis = new FileInputStream(extStore+"/Download/car.jpeg");
            byte[] image = new byte[fis.available()];
            fis.read(image);

            ContentValues values = new ContentValues();
            values.put("a", image);
            db.insert("tb", null, values);

            fis.close();

            Toast.makeText(this, "Guardado satisfactoriamente", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void recuperarImagen(View view) {

        Cursor c = db.rawQuery("select * from tb", null);
        if (c.moveToNext()){
            byte[] image = c.getBlob(1);
            Bitmap bitmap = BitmapFactory.decodeByteArray(image, 1, image.length );
            imageViewExterna.setImageBitmap(bitmap);

            Toast.makeText(this, "Recuperado satisfactoriamente", Toast.LENGTH_SHORT).show();

        }

    }
}
