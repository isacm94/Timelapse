package firebase.palma.com.sqlitetrianasat;

/**
 * Created by jmpgallego on 25/01/2017.
 */
public class Posicion {
}
