package com.crbejarano.timelapsedb;

import android.annotation.TargetApi;
import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class AdaptadorLista extends CursorAdapter {

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public AdaptadorLista(Context context, Cursor cursor, int flags) {
        super(context, cursor, 0);
    }


    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.activity_row, parent, false);
    }


    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        //Cogemos los elementos de la vista
        TextView textViewRutaImagen = (TextView) view.findViewById(R.id.text_view_ruta_imagen);

        //Extraemos los datos del cursor
        String ruta = cursor.getString(cursor.getColumnIndexOrThrow("titulo"));

        //Log.d("AdaptadorLista","Nota: "+nota.toString());

        //Guardamos en los elementos, los datos guardados en el cursor
        textViewRutaImagen.setText(ruta);

    }
}
