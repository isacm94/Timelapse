package com.crbejarano.timelapsedb;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.sql.SQLException;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView listViewImagenes;
    private Cursor cursor;
    ImagenesDB DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //BOTÓN +
        FloatingActionButton btn_MAS = (FloatingActionButton) findViewById(R.id.btn_aniadir);
        btn_MAS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getApplicationContext(), "Botón más pulsado", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), VistaImagenActivity.class);
                intent.putExtra("id", 0);
                startActivity(intent);
            }
        });

        DB = new ImagenesDB(this);
        InsertaDatosIniciales();
        ActualizaVista();
        listViewImagenes.setOnItemClickListener(this);//Click en cada linea de la lista

    }

    /**
     * Actualiza la vista con los datos actuales de la base de datos
     */
    protected void onResume(){
        super.onResume();
        ActualizaVista();
    }

    /**
     * Click en cada RowActivity de la lista, le pasamos el ID del libro
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, VistaImagenActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }

    /**
     * Carga todos los libros guardados en la lista
     */
    public void ActualizaVista() {
        listViewImagenes = (ListView) findViewById(R.id.list_view_imagenes);

        try {
            DB.openR();//Abrimos la Bd en modo lectura
        } catch (SQLException e) {
            e.printStackTrace();
        }

        cursor = DB.getLibros();//Guardamos en el cursor los libros

        if (cursor.moveToFirst()) {
            AdaptadorLista adaptador = new AdaptadorLista(this, cursor, 0);

            listViewImagenes.setAdapter(adaptador);//Pasamos al listview los libros del cursor
        }else{
            listViewImagenes.removeAllViewsInLayout();//Si no hay libros, borra sus información en el layout
        }

        DB.close();
    }

    /**
     * Añade a la base de datos todos los libros iniciales
     */
    public void InsertaDatosIniciales() {

        try {
            DB.openW();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (DB.getCount() == 0) {

                DB.insertLibro("https://www.google.es/");

                DB.insertLibro("http://salesianos-triana.tutormoodle.com/");

                DB.insertLibro("http://www.apple.com/es/");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        DB.close();
    }
}
